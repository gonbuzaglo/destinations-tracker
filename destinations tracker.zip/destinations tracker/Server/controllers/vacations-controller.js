const vacationsLogic = require("../bll/vacations-logic"),
    socketComm = require("../socket-comm"),
    express = require("express"),
    Vacation = require("../models/Vacation");

const router = express.Router();

// GET http://localhost:3001/api/vacations
router.get("/", async (request, response) => {
    try {
        const vacations = await vacationsLogic.getAllVacationsAsync();
        response.json(vacations);
    } catch (err) {
        response.status(500).json(err.message);
    }
});

// GET http://localhost:3001/api/vacations/user/userID
router.get("/user/:userID", async (request, response) => {
    try {
        const userID = +request.params.userID;
        const vacations = await vacationsLogic.getVacationsForUserAsync(userID);
        response.json(vacations);
    } catch (err) {
        response.status(500).json(err.message);
    }
});

// PUT http://localhost:3001/api/vacations/follow/2/2
router.put('/follow/:userID/:vacationID', async (request, response) => {
    try {
        const data = {

            "userID": +request.params.userID,
            "vacationID": +request.params.vacationID

        };
        await vacationsLogic.followVacationAsync(data);
        socketComm.emitFollow(data.vacationID);
        response.sendStatus(204);
    } catch (err) {
        response.status(500).json(err.message);
    }
});

// PUT http://localhost:3001/api/vacations/unFollow/2/2
router.put('/unFollow/:userID/:vacationID', async (request, response) => {
    try {
        const data = {

            "userID": +request.params.userID,
            "vacationID": +request.params.vacationID

        };
        await vacationsLogic.unFollowVacationAsync(data);
        socketComm.emitUnFollow(data.vacationID);
        response.sendStatus(204);
    } catch (err) {
        response.status(500).json(err.message);
    }
});

// POST http://localhost:3001/api/vacations/admin
router.post("/admin", async (request, response) => {
    try {
        const vacation = request.body;
        const errorDetails = Vacation.validate(vacation);
    
        if (errorDetails) {
            response.status(400).json({
                error: errorDetails.join(', ')
            });
            return;
        }
        const addedVacation = await vacationsLogic.addVacationAsync(vacation);
        socketComm.emitVacation(addedVacation);
        response.status(201).json(addedVacation);
    }
    catch(err) {
        response.status(500).json(err.message);
    }
});

// PUT http://localhost:3001/api/vacations/admin/7
router.put("/admin/:vacationID", async (request, response) => {
    try {
        const vacationID = +request.params.vacationID;
        const vacation = request.body;
        console.log(vacation);
        vacation.vacationID = vacationID;
        const updatedVacation = await vacationsLogic.updateVacationAsync(vacation);
        socketComm.emitUpdateVacation(updatedVacation);
        console.log(updatedVacation);
        response.json(updatedVacation);
    } catch (err) {
        response.status(500).json(err.message);
    }
});

// DELETE http://localhost:3001/api/vacations/admin/7
router.delete("/admin/:vacationID", async (request, response) => {
    try {
        const vacationID = +request.params.vacationID;
        await vacationsLogic.deleteVacationAsync(vacationID);
        socketComm.emitDeleteVacation(vacationID);
        response.sendStatus(204);
    } catch (err) {
        response.status(500).json(err.message);
    }
});

module.exports = router;