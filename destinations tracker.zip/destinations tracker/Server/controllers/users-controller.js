const express = require("express"),
    usersLogic = require("../bll/users-logic"),
    User = require("../models/User");

const router = express.Router();

router.post("/login", async (request, response) => {
    const credentials = request.body;
    const admin = await usersLogic.isAdminAsync(credentials);
    if (admin) {
        response.json({
            userID: 0,
            username: admin.adminName,
            isAdmin: true
        });
        return;
    }
    const user = await usersLogic.loginAsync(credentials);
    if (user) {
        response.json(user);
        return;
    } else {
        response.json({
            error: "Incorrect username or password"
        });
    }
});

router.post("/sign-up", async (request, response) => {
    const user = request.body,
        errorDetails = User.validate(user),
        isUserAllReadyExists = await usersLogic.isUserAllReadyExistsAsync(user),
        isAdmin = await usersLogic.isAdminAsync(user);
    if (errorDetails) {
        response.status(400).json({
            error: errorDetails.join(', ')
        });
    } else if (isUserAllReadyExists === false && isAdmin === undefined) {
        const newUser = await usersLogic.signUpAsync(user);
        response.status(201).json(newUser);
    } else {
        response.status(409).json({
            error: "Username or password already exists"
        });
    }
});

module.exports = router;