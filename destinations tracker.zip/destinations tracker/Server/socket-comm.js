const express = require("express");
const io = require("socket.io");

const expressServer = express();
const expressListener = expressServer.listen(3002, () => console.log("Socket is on (port 3002)"));
const socketServer = io(expressListener);

// Listen to client connections: 
socketServer.sockets.on("connection", socket => {

    console.log("Client Connected. Total Clients: " + socketServer.engine.clientsCount);

    // Client has been disconnected: 
    socket.on("disconnect", () => {
        console.log("Client Disconnected. Total Clients: " + socketServer.engine.clientsCount);
    });
});

// Sending to all socket clients that a new vacation has been added: 
function emitVacation(vacation) {
    socketServer.sockets.emit("vacation-added", vacation);
}

function emitFollow(vacationID) {
    socketServer.sockets.emit("follow-vacation", vacationID);
}

function emitUnFollow(vacationID) {
    socketServer.sockets.emit("unFollow-vacation", vacationID);
}

function emitDeleteVacation(vacationID) {
    socketServer.sockets.emit("vacation-deleted", vacationID);
}

function emitUpdateVacation(vacation) {
    socketServer.sockets.emit("vacation-updated", vacation);
}

module.exports = {
    emitVacation,
    emitFollow,
    emitUnFollow,
    emitDeleteVacation,
    emitUpdateVacation
};
