const express = require("express"),
    cors = require("cors"),
    usersController = require("./controllers/users-controller"),
    vacationsController = require("./controllers/vacations-controller"),
    multer = require("multer"),
    fs = require("fs"),
    path = require("path");

const server = express();
server.use(express.json());
server.use(cors());

server.use(express.static(__dirname)); // Expose index.html resides in the root directory.

const upload = multer({ dest: __dirname + "\\assets\\pictures" });

// userImage is the name of the html input file element.

server.post("/upload-image", upload.single("userImage"), (request, response) => {
    const currentFile = request.file.destination + "\\" + request.file.filename;
    const newFile = currentFile + path.extname(request.file.originalname);
    fs.rename(currentFile, newFile, err => {
        if (err) {
            response.status(500).json(err);
            return;
        }
        response.json(request.file.filename + path.extname(request.file.originalname));
    });

});

server.use("/api", usersController);
server.use("/api/vacations", vacationsController);

server.listen(3001, () => console.log("Listening (port 3001)"));