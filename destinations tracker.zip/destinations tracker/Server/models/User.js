const Joi = require("joi");

class User {
    constructor(userID, firstName, lastName, username, password) {
        this.userID = userID;
        this. firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
    }

    static validate(user) {

        // Define validation schema: 
        const validationSchema = {
            userID: Joi.number(),
            isAdmin: Joi.bool(),
            firstName: Joi.string().required(),
            lastName: Joi.string().required(),
            username: Joi.string().required().min(4),
            password: Joi.string().min(4)
        };

        // Perform the validation: 
        const error = Joi.validate(user, validationSchema, { abortEarly: false }).error;

        // If validation failed - there is some object in error:
        if(error) {

            // Return error message: 
            return error.details.map(err => err.message);
        }

        // If there is no error - return null: 
        return null;
    }
}

module.exports = User;