class Admin {
    constructor(adminId, adminName, password){
        this.adminId = adminId;
        this.adminName = adminName;
        this.password = password;
    }
}