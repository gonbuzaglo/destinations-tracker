const Joi = require("joi");

class Vacation {
    constructor(vacationId, description, destination, photoPath, startDate, endDate, price, followers, isFollowedByUser) {
        this.vacationId = vacationId;
        this.description = description;
        this.destination = destination;
        this.photoPath = photoPath;
        this.startDate = startDate;
        this.endDate = endDate;
        this.price = price;
        this.isFollowedByUser = isFollowedByUser;
        this.followers = followers;
    }

    static validate(vacation) {

        // Define validation schema: 
        const validationSchema = {
            startDate: Joi.date().iso().required(),
            endDate : Joi.date().iso().greater(Joi.ref('startDate')).required(),
            destination: Joi.string().required(),
            description: Joi.string().allow('', null),
            photoPath: Joi.string().allow('', null),
            vacationID: Joi.number(),
            followers: Joi.number(),
            isFollowedByUser: Joi.boolean(),
            price: Joi.number().required().min(0).max(10000),
        };

        // Perform the validation: 
        const error = Joi.validate(vacation, validationSchema, { abortEarly: false }).error;

        // If validation failed - there is some object in error:
        if(error) {

            // Return error message: 
            return error.details.map(err => err.message);
        }

        // If there is no error - return null: 
        return null;
    }
}

module.exports = Vacation;