const dal = require("../dal/dal");

async function loginAsync(credentials) {
    const sql = `SELECT userID, firstName, lastName, username FROM Users
        WHERE BINARY username='${credentials.username}' AND password='${credentials.password}'`;

    const users = await dal.execute(sql);

    return users[0];
}

async function isUserAllReadyExistsAsync(credentials) {
    const sql = `SELECT userID, firstName, lastName, username FROM Users
    WHERE BINARY username='${credentials.username}' OR password='${credentials.password}'`;

    const users = await dal.execute(sql);

    return users.length > 0;
}

async function isAdminAsync(credentials) {
    const sql = `SELECT adminID, adminName FROM admins
    WHERE BINARY adminName='${credentials.username}' AND password='${credentials.password}'`;

    const admins = await dal.execute(sql);

    return admins[0];
}

async function signUpAsync(credentials) {
    const sql = `INSERT INTO users VALUES(null, '${credentials.firstName}', '${credentials.lastName}', 
    '${credentials.username}', '${credentials.password}')`,
        info = await dal.execute(sql);

    return {
        ...credentials,
        userID: info.insertId
    }
}

module.exports = {
    loginAsync,
    signUpAsync,
    isUserAllReadyExistsAsync,
    isAdminAsync
};