const dal = require("../dal/dal");

// for both user and admin:
async function getAllVacationsAsync() {
    const sql = `SELECT * FROM vacations`,
        vacations = dal.execute(sql);
    return vacations;
}

// for user:
async function getVacationsForUserAsync(userID) {
    const sql1 = `SELECT * FROM vacations as V JOIN user_vacations as UV 
    ON V.vacationID = UV.vacationID 
    WHERE UV.userID = ${userID}`;
    const sql2 = `SELECT * 
    FROM vacations 
    WHERE vacationID NOT IN (SELECT vacationID FROM user_vacations WHERE userID=${userID})`;
    const followed = await dal.execute(sql1);
    const unFollowed = await dal.execute(sql2);
    followed.forEach(v => v.isFollowedByUser = true);
    return [...followed, ...unFollowed];
}

async function followVacationAsync(data) {
    const sql = `INSERT INTO user_vacations(vacationID, userID) values(${data.vacationID}, ${data.userID}); 
    UPDATE vacations SET followers = followers + 1 WHERE vacationID = ${data.vacationID}`;
    await dal.execute(sql);
    return;
}

async function unFollowVacationAsync(data) {
    const sql = `DELETE from user_vacations WHERE vacationID = ${data.vacationID} AND userID = ${data.userID}; 
    UPDATE vacations SET followers = followers - 1 WHERE vacationID = ${data.vacationID}`;
    await dal.execute(sql);
    return;
}

// for admin:
async function addVacationAsync(vacation) {
    const sql = `INSERT INTO 
    vacations(description, destination, photoPath, startDate, endDate, price)
    VALUES('${vacation.description}',
        '${vacation.destination}',
        '${vacation.photoPath}',
        '${vacation.startDate}',
        '${vacation.endDate}',
        '${vacation.price}')`,
        info = await dal.execute(sql);
    return {
        ...vacation,
        vacationID: info.insertId
    }
}

async function updateVacationAsync(vacation) {
    const sql = `UPDATE vacations SET description = '${vacation.description}',
    destination = '${vacation.destination}', photoPath = '${vacation.photoPath}', 
    endDate = '${vacation.endDate}', startDate = '${vacation.startDate}', price = '${vacation.price}', 
    followers = '${vacation.followers}'
                WHERE vacationID = ${vacation.vacationID}`;
    await dal.execute(sql);
    return vacation;
}

async function deleteVacationAsync(id) {
    const sql = `DELETE from user_vacations WHERE vacationID = ${id}; 
    delete from vacations where vacationID = ${id}`;
    await dal.execute(sql);
}

module.exports = {
    getAllVacationsAsync,
    addVacationAsync,
    updateVacationAsync,
    deleteVacationAsync,
    getVacationsForUserAsync,
    followVacationAsync,
    unFollowVacationAsync,
};