import { User } from "../models/User";
import { Vacation } from "../models/Vacation";

// מחלקה המכילה בתוכה את המידע של כל האפליקציה

export class AppState {
    public user: User = new User();
    public vacations: Vacation[] = [];
}