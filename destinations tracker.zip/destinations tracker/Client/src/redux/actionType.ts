// enum = רשימה סגורה של קבועים

export enum ActionType { // close list of constants
    login,
    logout,
    vacationAdded,
    getFollowedByUserVacations,
    getUnFollowedByUserVacations,
    getAllVacations,
    followVacation,
    unFollowVacation,
    clearVacations,
    deleteVacation,
    updateVacation
}

