import { AppState } from "./appState";
import { AnyAction, combineReducers } from "redux";
import { ActionType } from "./actionType";
import { User } from "../models/User";

function usersReducer(oldAppState: AppState | undefined, action: AnyAction): AppState {

    if (!oldAppState) {
        return new AppState();
    }

    const newAppState = { ...oldAppState };

    switch (action.type) {
        case ActionType.login:
            newAppState.user = action.payload;
            break;

        case ActionType.logout:
            newAppState.user = new User();
            break;

    }

    return newAppState;
}

function vacationsReducer(oldAppState: AppState | undefined, action: AnyAction): AppState {

    if (!oldAppState) {
        return new AppState();
    }

    const newAppState = { ...oldAppState };

    let index: number;

    switch (action.type) {
        case ActionType.vacationAdded:
            newAppState.vacations.push(action.payload);
            break;

        case ActionType.getAllVacations:
            newAppState.vacations = action.payload;
            break;

        case ActionType.followVacation:
            index = newAppState.vacations.findIndex(v => v.vacationID === action.payload);
            newAppState.vacations[index].followers++;
            newAppState.vacations[index].isFollowedByUser = true;
            break;

        case ActionType.unFollowVacation:
            index = newAppState.vacations.findIndex(v => v.vacationID === action.payload);
            newAppState.vacations[index].followers--;
            newAppState.vacations[index].isFollowedByUser = false;
            break;

        case ActionType.clearVacations:
            newAppState.vacations = [];
            break;

        case ActionType.deleteVacation:
            index = newAppState.vacations.findIndex(v => v.vacationID === action.payload);
            newAppState.vacations.splice(index, 1);
            break;

        case ActionType.updateVacation:
            index = newAppState.vacations.findIndex(v => v.vacationID === action.payload.vacationID);
            newAppState.vacations[index] = action.payload;
            break;
    }

    return newAppState;
}

export const allReducers = combineReducers({ usersReducer, vacationsReducer });