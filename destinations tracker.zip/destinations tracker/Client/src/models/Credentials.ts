export class Credentials {
    public constructor(
        public username?: string,
        public password?: string,
    ){ }
}