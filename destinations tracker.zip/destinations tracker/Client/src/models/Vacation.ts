export class Vacation {
    public constructor(
        public vacationID: number = 0,
        public description: string = '',
        public destination?: string,
        public photoPath: string = '',
        public startDate?: any,
        public endDate?: any,
        public price?: number,
        public followers: number = 0,
        public isFollowedByUser: boolean = false
    ){}
    public static formatDate = (dateString: string): string => (
        new Date(dateString).toLocaleDateString()
    );
}