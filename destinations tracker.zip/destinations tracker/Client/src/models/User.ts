export class User {
    public constructor(
        public userID: number = -1,
        public firstName: string = '',
        public lastName: string = '',
        public username: string = '',
        public password: string = '',
        public isAdmin: boolean = false,
    ){ }
}