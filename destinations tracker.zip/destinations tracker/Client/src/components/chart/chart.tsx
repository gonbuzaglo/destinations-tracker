import CanvasJSReact from "../../assets/canvasjs.react";
import React, { Component } from "react";
import { Vacation } from "../../models/Vacation";
import { Unsubscribe } from "redux";
import { store } from "../../redux/store";
import { ActionType } from "../../redux/actionType";
import io from "socket.io-client";

const CanvasJSChart = CanvasJSReact.CanvasJSChart;

interface IChartState {
    followedVacations: Vacation[];
}

export class Chart extends Component<any, IChartState> {	
    private unsubscribedStore: Unsubscribe;
    private socket = io.connect("http://localhost:3002"); // Server Address
    
    public constructor(props: any) {
        super(props);
        this.state = {
            followedVacations: store.getState().vacationsReducer.vacations.filter(v => v.followers > 0)
        };
        this.unsubscribedStore = store.subscribe(() => this.setState({
            followedVacations: store.getState().vacationsReducer.vacations.filter(v => v.followers > 0)
        }))
                // Listen to vacation-added which will be invoked from the server: 
                this.socket.on("vacation-added", (vacation: Vacation) => {
                    store.dispatch({ type: ActionType.vacationAdded, payload: vacation });
                });
        
                // Listen to follow-vacation which will be invoked from the server: 
                this.socket.on("follow-vacation", (vacationID: number) => {
                    store.dispatch({ type: ActionType.followVacation, payload: vacationID });
                });
        
                // Listen to unFollow-vacation which will be invoked from the server: 
                this.socket.on("unFollow-vacation", (vacationID: number) => {
                    store.dispatch({ type: ActionType.unFollowVacation, payload: vacationID });
                });
        
                this.socket.on("vacation-deleted", (vacationID: number) => {
                    store.dispatch({ type: ActionType.deleteVacation, payload: vacationID });
                });
        
                this.socket.on("vacation-updated", (vacation: Vacation) => {
                    store.dispatch({ type: ActionType.updateVacation, payload: vacation });
                });
    }

    public componentWillUnmount(): void {
        this.socket.close();
        this.unsubscribedStore();
    }

    public componentDidMount(): void {
        if (this.state.followedVacations.length === 0) {
                fetch("http://localhost:3001/api/vacations")
                    .then(response => response.json())
                    .then(vacations => store.dispatch({ type: ActionType.getAllVacations, payload: vacations }))
                    .catch(err => alert(err));
        }
    }
    
    public render(): JSX.Element {
      const options = {
        title: {
          text: "Followers Per Vacation"
        },
        data: [{				
                  type: "column",
                  dataPoints: this.state.followedVacations.map(fv => ({ label: fv.destination, y: fv.followers }))
         }]
     }
          
     return (
        <div>
          <CanvasJSChart options = {options}
              /* onRef = {ref => this.chart = ref} */
          />
        </div>
      );
    }
  }