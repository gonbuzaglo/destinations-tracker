import React, { Component } from 'react';
import './vacations.css';
import io from "socket.io-client";
import { Vacation } from '../../models/Vacation';
import { Unsubscribe } from 'redux';
import { store } from '../../redux/store';
import { ActionType } from '../../redux/actionType';
import { User } from '../../models/User';
import { EditVacation } from '../edit-vacation/edit-vacation';

interface VacationsState {
    vacations: Vacation[];
    user: User;
    editing: number;
}

export class Vacations extends Component<any, VacationsState> {
    private unsubscribedStore: Unsubscribe;
    // Create the comm line to the server on the socket.io library: 
    private socket = io.connect("http://localhost:3002"); // Server Address

    public constructor(props: any) {
        super(props);
        this.state = {
            vacations: store.getState().vacationsReducer.vacations,
            user: JSON.parse(sessionStorage.getItem('user')),
            editing: 0
        };
        this.unsubscribedStore = store.subscribe(() => this.setState({
            vacations: store.getState().vacationsReducer.vacations,
        }))
        // Listen to vacation-added which will be invoked from the server: 
        this.socket.on("vacation-added", (vacation: Vacation) => {
            store.dispatch({ type: ActionType.vacationAdded, payload: vacation });
        });

        // Listen to follow-vacation which will be invoked from the server: 
        this.socket.on("follow-vacation", (vacationID: number) => {
            store.dispatch({ type: ActionType.followVacation, payload: vacationID });
        });

        // Listen to unFollow-vacation which will be invoked from the server: 
        this.socket.on("unFollow-vacation", (vacationID: number) => {
            store.dispatch({ type: ActionType.unFollowVacation, payload: vacationID });
        });

        this.socket.on("vacation-deleted", (vacationID: number) => {
            store.dispatch({ type: ActionType.deleteVacation, payload: vacationID });
        });

        this.socket.on("vacation-updated", (vacation: Vacation) => {
            store.dispatch({ type: ActionType.updateVacation, payload: vacation });
        });
    }

    public componentWillUnmount(): void { //with redux
        this.socket.close();
        this.unsubscribedStore();
    }


    public componentDidMount(): void {
        const userFromSessionStorage = JSON.parse(sessionStorage.getItem('user'));
        if (userFromSessionStorage === null) {
            this.socket.close();
            this.props.history.push("/login");
        }
        else if (this.state.vacations.length === 0) {
            if (this.state.user.isAdmin === true) {
                fetch("http://localhost:3001/api/vacations")
                    .then(response => response.json())
                    .then(vacations => store.dispatch({ type: ActionType.getAllVacations, payload: vacations }))
                    .catch(err => alert(err));
            }
            else { // if not admin, display followed by the user vacations first
                fetch("http://localhost:3001/api/vacations/user/" + this.state.user.userID)
                    .then(response => response.json())
                    .then(vacations => store.dispatch({ type: ActionType.getAllVacations, payload: vacations }))
                    .catch(err => alert(err));
            }
        }
    }

    private getBorderStyle(isFollowedByUser: boolean): {} {
        if (isFollowedByUser) {
            return {
                borderColor: "blue"
            };
        }
        else {
            return {
                borderColor: "black"
            };
        }
    }

    private followVacation(vacationID: number): void {
        fetch('http://localhost:3001/api/vacations/follow/' + this.state.user.userID + '/' + vacationID, {
            method: 'PUT'
        })
            .catch(err => alert(err));
    }

    private unFollowVacation(vacationID: number): void {
        fetch('http://localhost:3001/api/vacations/unFollow/' + this.state.user.userID + '/' + vacationID, {
            method: 'PUT'
        })
            .catch(err => alert(err));
    }

    private deleteVacation(vacationID: number): void {
        const c = window.confirm('are you sure you\'d like to delete vacation #' + vacationID + '?');
        if (c === true) {
            fetch('http://localhost:3001/api/vacations/admin/' + vacationID, {
                method: 'DELETE'
            })
                .catch(err => alert(err));
        }
    }

    private updateVacation = (vacation: Vacation): void => {
        fetch('http://localhost:3001/api/vacations/admin/' + vacation.vacationID, {
            method: 'PUT',
            headers: {
                "Content-Type": "application/json", //what type are we sending.
                "Accept": "application/json" //what are we expecting to get back
            },
            body: JSON.stringify(vacation)
        })
            .then(response => response.json())
            .then(vacation => {
                alert('vacation has been updated. vacation ID: ' + vacation.vacationID)
            })
            .catch(err => alert(err));
    }

    public render(): JSX.Element {
        return (
            <div className="vacations">
                {this.state.vacations.length > 0 ?
                    this.state.vacations.map(v =>
                        this.state.user.isAdmin && this.state.editing === v.vacationID ?
                        <div key={v.vacationID} className="one-vacation-form">
                            <EditVacation vacation={v} onSave={this.updateVacation} onCancel={() => this.setState({ editing: 0 })} />
                        </div>
                            :
                            <div className="one-vacation" key={v.vacationID} style={this.getBorderStyle(v.isFollowedByUser)}>
                                {this.state.user.isAdmin && <button className='vacation-button' onClick={() => this.deleteVacation(v.vacationID)}><i className="fa fa-trash"></i></button>}
                                {this.state.user.isAdmin ?
                                    <button className='vacation-button' onClick={() => this.setState({ editing: v.vacationID })}><i className="fa fa-pencil-square-o"></i></button> : v.isFollowedByUser ?
                                        <button className='vacation-button' onClick={() => this.unFollowVacation(v.vacationID)}><i className="fa fa-minus"></i></button> :
                                        <button className='vacation-button' onClick={() => this.followVacation(v.vacationID)}><i className="fa fa-plus"></i></button>
                                }
                                <h4>Vacation To {v.destination}</h4>
                                <h4>from: {Vacation.formatDate(v.startDate)}</h4>
                                <h4>until: {Vacation.formatDate(v.endDate)}</h4>
                                <h4>description: {v.description}</h4>
                                <h4>followers: {v.followers}</h4>
                                <h5>price: ${v.price}</h5>
                                <img height="215" width="350" src={'http://127.0.0.1:3001/assets/pictures/' + v.photoPath} alt={v.photoPath} />
                            </div>
                    )
                    : <h1>loading</h1>}
            </div>

        );
    }
}