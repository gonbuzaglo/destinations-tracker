import React from 'react';
import './home.css';

export const Home: React.FC = (): JSX.Element => {
    return(
        <div className="home">
            <h1>My Very Cool Vacations Project!</h1>
            <p>
                This is my biggest react project so far. I really love react, because it's fun to use
                and cool. I built the whole project at Rosh HaShana, then came to it every once in a while 
                to fix some bugs and make sure it works. the database comes with 4 pre-made vacations, and you may add
                as many as you like after downloading the sql file under "database" folder in the root directory of this project.
                The project also comes with pre-made users, including the classical Moshiko and Kipi Ben Kipod.
                <br/><br/>
                This is the third project made in a "Fullstack Web Developer" course in John Bryce, TLV.
            </p>
            <h2>Technologies used in this project:</h2>
            <ul>
                <li>react</li>
                <li>redux</li>
                <li>Typescript</li>
                <li>node.js</li>
                <li>mySql</li>
                <li>express</li>
                <li>socket.io</li>
            </ul>
        </div>
    );
}