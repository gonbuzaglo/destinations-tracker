import React, { Component } from 'react';
import './edit-vacation.css';
import { Vacation } from '../../models/Vacation';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

interface IEditVacationProps {
    vacation: Vacation;
    onSave: (vacation: Vacation) => void;
    onCancel: () => void;
}

interface IEditVacationState {
    vacation: Vacation;
    errors: {
        startDateError: string;
        endDateError: string;
        priceError: string;
        descriptionError: string;
    };
}

export class EditVacation extends Component<IEditVacationProps, IEditVacationState> {
    public constructor(props: IEditVacationProps) {
        super(props);
        this.state = {
            vacation: this.props.vacation,
            errors: {
                startDateError: "",
                endDateError: "",
                priceError: "",
                descriptionError: "",
            },
        }
    }

    private setPrice = (e: any): void => {
        const price = e.target.value === "" ? undefined : +e.target.value;
        // Take the vacation, change it's price' and return it back to the state:

        let priceError = "";

        if (price === undefined) {
            priceError = "Missing price.";
        }
        else if (price < 0) {
            priceError = "price can't be negative."
        }
        else if (price > 10000) {
            priceError = "price can't be over 10,000."
        }

        const vacation = { ...this.state.vacation }; //Spread Operator
        vacation.price = price;
        const errors = { ...this.state.errors };
        errors.priceError = priceError;
        this.setState({ vacation, errors });
    };

    private setDescription = (e: any): void => {
        const description = e.target.value === "" ? undefined : e.target.value;
        // Take the vacation, change it's description' and return it back to the state:

        let descriptionError = "";

        if (description === undefined) {
            descriptionError = "Missing description.";
        }
        else if (description < 0) {
            descriptionError = "description can't be negative."
        }
        else if (description > 10000) {
            descriptionError = "description can't be over 10,000."
        }

        const vacation = { ...this.state.vacation }; //Spread Operator
        vacation.description = description;
        const errors = { ...this.state.errors };
        errors.descriptionError = descriptionError;
        this.setState({ vacation, errors });
    };

    private setStartDate = (date: any): void => {
        const startDate = new Date(date);
        const endDate = new Date(this.state.vacation.endDate);
        let startDateError = "";
        let endDateError = "";

        if (startDate.getTime() > endDate.getTime()) {
            startDateError = "Start date must be earlier than end date";
        }
        if (endDate.getTime() < startDate.getTime()) {
            endDateError = "End date must be later than start date";
        }

        const vacation = { ...this.state.vacation };
        const errors = { ...this.state.errors };
        vacation.startDate = startDate;
        errors.startDateError = startDateError;
        errors.endDateError = endDateError;
        this.setState({ vacation, errors });
    };

    private setEndDate = (date: any): void => {
        const endDate = new Date(date);
        const startDate = new Date(this.state.vacation.startDate);
        let startDateError = "";
        let endDateError = "";

        if (startDate.getTime() > endDate.getTime()) {
            startDateError = "Start date must be earlier than end date";
        }
        if (endDate.getTime() < startDate.getTime()) {
            endDateError = "End date must be later than start date";
        }

        const vacation = { ...this.state.vacation };
        const errors = { ...this.state.errors };
        vacation.endDate = endDate;
        errors.startDateError = startDateError;
        errors.endDateError = endDateError;
        this.setState({ vacation, errors });
    };

    private isFormLegal(): boolean {
        return this.state.errors.priceError === "" &&
            this.state.errors.startDateError === "" &&
            this.state.errors.endDateError === "";

    }

    private getValidationStyle(errorMessage: string): {} {
        if (errorMessage) {
            return {
                backgroundColor: "pink",
                border: "1px solid black"
            };
        } else {
            return {
                backgroundColor: "white",
                border: "1px solid black"
            };
        }
    }

    handleUploadfile = (event) => {
        event.preventDefault();
        const data = new FormData();
        console.log(event.target.files[0]);
        data.append("userImage", event.target.files[0]);
        console.log(data);
        fetch("http://localhost:3001/upload-image", {
            method: 'POST',
            //  headers: {
            //      'Accept': 'application/json'
            //  },
            body: data
        }).then(response => response.json())
            .then(photoPath => {
                const vacation = { ...this.state.vacation };
                vacation.photoPath = photoPath;
                this.setState({ vacation });
            })
            .catch(err => alert(err));
    }

    public render(): JSX.Element {
        return (
            <div className="edit-vacation">
                <form id="image-form">
                    <input type="file" accept="image/*" name="userImage" onChange={this.handleUploadfile} />
                    <br />
                </form>
                
                <form>
                    <input style={this.getValidationStyle(this.state.errors.priceError)} type="number" placeholder="Price..."
                        onChange={this.setPrice} value={this.state.vacation.price || ""} />
                    <span>{this.state.errors.priceError}</span>
                    
                    <br />
                    
                    <input style={this.getValidationStyle(this.state.errors.descriptionError)} type="text" placeholder="description..."
                        onChange={this.setDescription} value={this.state.vacation.description || ""} />
                   
                    <br />
                   
                    <label>from: </label>
                    <span style={this.getValidationStyle(this.state.errors.startDateError)}>
                        <DatePicker
                            selected={this.state.vacation.startDate && new Date(this.state.vacation.startDate)}
                            onChange={this.setStartDate}
                        />
                        <br />
                        {this.state.errors.startDateError !== "" && <span>{this.state.errors.startDateError}</span>}
                    </span>
                   
                    <br/><br/>
                   
                    <label>until: </label>
                    <span style={this.getValidationStyle(this.state.errors.endDateError)}>
                        <DatePicker
                            selected={this.state.vacation.endDate && new Date(this.state.vacation.endDate)}
                            onChange={this.setEndDate}
                        />
                    </span>
                   
                    <br/>
                   
                    {this.state.errors.endDateError !== "" && <span>{this.state.errors.endDateError}</span>}
                  
                    <br/>
                  
                    <button onClick={this.props.onCancel}>cancel</button>
                    <button disabled={!this.isFormLegal()} onClick={() => this.props.onSave(this.state.vacation)}>Save Changes</button>
                </form>
            </div>
        );
    }
}
