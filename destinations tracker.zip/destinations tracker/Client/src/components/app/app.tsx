import React, { Component } from 'react';
import "./app.css";
import { BrowserRouter, NavLink, Switch, Route, Redirect } from 'react-router-dom';
import { Home } from '../home/home';
import { Login } from '../login/login';
import { SignUp } from '../sign-up/sign-up';
import { store } from '../../redux/store';
import { ActionType } from '../../redux/actionType';
import { User } from '../../models/User';
import { Unsubscribe } from 'redux';
import { Vacations } from '../vacations/vacations';
import { addVacation } from '../add-vacation/add-vacation';
import { Chart } from '../chart/chart';
import { Footer } from '../footer/footer';

interface IAppState {
    user: User;
}

export class App extends Component<any, IAppState> {
    private unsubscribedStore: Unsubscribe;

    public constructor(props: any) {
        super(props);
        this.state = {
            user: store.getState().usersReducer.user
        };
        this.unsubscribedStore = store.subscribe(() => this.setState({
            user: store.getState().usersReducer.user
        }))

    }

    public componentDidMount(): void {
        if (sessionStorage.getItem('user') !== null && this.state.user.userID === -1) {
            const user = JSON.parse(sessionStorage.getItem('user'))
            store.dispatch({ type: ActionType.login, payload: user })
        }
    }

    public componentWillUnmount(): void { //with redux
        this.unsubscribedStore();
    }

    private logout = (): void => {
        store.dispatch({ type: ActionType.logout });
        store.dispatch({ type: ActionType.clearVacations });
        sessionStorage.clear();
    }

    private isLoggedIn = (): boolean => this.state.user.userID > -1;

    public render(): JSX.Element {
        return (
            <div className="app">
                <BrowserRouter>
                    <ul>
                        <li><span><NavLink to="/home" exact>Home</NavLink></span></li>
                        <li><span><NavLink to="/vacations" exact>Vacations</NavLink></span></li>
                        {this.state.user.isAdmin === true &&
                            <>
                                <li><span><NavLink to="/vacations/new" exact>Add Vacation</NavLink></span></li>
                                <li><span><NavLink to="/chart" exact>Chart</NavLink></span></li>
                            </>
                        }
                        <li>
                            <span>
                                <NavLink style={{ display: this.isLoggedIn() ? "none" : "inline" }} to="/login" exact>Login </NavLink>
                                <NavLink style={{ display: this.isLoggedIn() ? "inline" : "none" }} to="/home" exact onClick={this.logout}>Logout</NavLink>
                            </span>
                        </li>
                        {sessionStorage.getItem("user") !== null && 
                        <h3 id="greeting">Hello {this.state.user.username} :)</h3>}
                    </ul>
                    <main>

                        <Switch>
                            <Route path="/home" component={Home} exact />
                            <Route path="/login" component={Login} exact />
                            <Route path="/sign-up" component={SignUp} exact />
                            <Route path="/vacations" component={Vacations} exact />
                            <Route path="/vacations/new" component={addVacation} exact />
                            <Route path="/chart" component={Chart} exact />
                            <Redirect from="/" to="/home" exact />
                        </Switch>

                    </main>

                </BrowserRouter>

                <Footer/>
            </div>
        );
    }
}