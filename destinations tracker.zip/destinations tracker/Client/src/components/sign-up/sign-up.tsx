import React, { Component, ChangeEvent } from "react";
import "./sign-up.css";
import { User } from "../../models/User";

interface SignUpState {
    user: User;
    errors: {
        firstNameError: string;
        lastNameError: string;
        usernameError: string;
        passwordError: string;
    }
}

export class SignUp extends Component<any, SignUpState> {

    public constructor(props: any) {
        super(props);
        this.state = {
            user: new User(),
            errors: {
                firstNameError: "*",
                lastNameError: "*",
                usernameError: "*",
                passwordError: "*",
            }
        };
    }

    private setUsername = (e: ChangeEvent<HTMLInputElement>): void => {
        const username = e.target.value;
        let usernameError = "";

        if (username === "") {
            usernameError = "Missing username.";
        }
        else if (username.length < 4) {
            usernameError = "Username too short."
        }

        const user = { ...this.state.user };
        const errors = { ...this.state.errors };
        user.username = username;
        errors.usernameError = usernameError;
        this.setState({ user, errors });
    };

    private setFirstName = (e: ChangeEvent<HTMLInputElement>): void => {
        const firstName = e.target.value;
        let firstNameError = "";

        if (firstName === "") {
            firstNameError = "Missing first name.";
        }

        const user = { ...this.state.user };
        const errors = { ...this.state.errors };
        user.firstName = firstName;
        errors.firstNameError = firstNameError;
        this.setState({ user, errors });
    };

    private setLastName = (e: ChangeEvent<HTMLInputElement>): void => {
        const lastName = e.target.value;
        let lastNameError = "";

        if (lastName === "") {
            lastNameError = "Missing last name.";
        }

        const user = { ...this.state.user };
        const errors = { ...this.state.errors };
        user.lastName = lastName;
        errors.lastNameError = lastNameError;
        this.setState({ user, errors });
    };

    private setPassword = (e: ChangeEvent<HTMLInputElement>): void => {
        const password = e.target.value;
        let passwordError = "";

        if (password === "") {
            passwordError = "Missing password.";
        }
        else if (password.length < 4) {
            passwordError = "Password too short."
        }

        const user = { ...this.state.user };
        const errors = { ...this.state.errors };
        user.password = password;
        errors.passwordError = passwordError;
        this.setState({ user, errors });
    };

    private SignUp = (): void => {
        fetch("http://localhost:3001/api/sign-up", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json"
            },
            body: JSON.stringify(this.state.user)
        })
            .then(response => response.json())
            .then(user => {
                if (user.hasOwnProperty('error')) {
                    alert(user.error);
                }
                else {
                    alert("You've been signed up successfully!")

                    this.props.history.push("/login");
                }
            })
            .catch(err => alert(err));
    };

    private isFormLegal(): boolean {
        return this.state.errors.usernameError === "" &&
            this.state.errors.passwordError === "" &&
            this.state.errors.firstNameError === "" &&
            this.state.errors.lastNameError === "";
    }

    private getValidationStyle(errorMessage: string): {} {
        if (errorMessage) {
            return {
                backgroundColor: "pink",
                border: "2px solid red"
            };
        }
        else {
            return {
                backgroundColor: "white",
                border: "1px solid black"
            };
        }
    }

    public render(): JSX.Element {
        return (
            <div className="sign-up">

                <h2>Sign Up</h2>

                <form>

                    <input style={this.getValidationStyle(this.state.errors.firstNameError)} type="text"
                        placeholder="First name..." onChange={this.setFirstName} value={this.state.user.firstName || ""} autoFocus />
                    <span>{this.state.errors.firstNameError}</span>
                    <br /><br />

                    <input style={this.getValidationStyle(this.state.errors.lastNameError)} type="text"
                        placeholder="Last name..." onChange={this.setLastName} value={this.state.user.lastName || ""} />
                    <span>{this.state.errors.lastNameError}</span>
                    <br /><br />

                    <input style={this.getValidationStyle(this.state.errors.usernameError)} type="text"
                        placeholder="Username..." onChange={this.setUsername} value={this.state.user.username || ""} />
                    <span>{this.state.errors.usernameError}</span>
                    <br /><br />

                    <input style={this.getValidationStyle(this.state.errors.passwordError)} type="password"
                        placeholder="Password..." onChange={this.setPassword} value={this.state.user.password || ""} />
                    <span>{this.state.errors.passwordError}</span>
                    <br /><br />

                    <button disabled={!this.isFormLegal()} type="button" onClick={this.SignUp}>SignUp</button>

                </form>

            </div>
        );
    }
}