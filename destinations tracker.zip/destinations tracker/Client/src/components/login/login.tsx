import React, { Component, ChangeEvent } from "react";
import "./login.css";
import { Credentials } from "../../models/Credentials";
import { NavLink } from "react-router-dom";
import { store } from "../../redux/store";
import { ActionType } from "../../redux/actionType";

interface LoginState {
    credentials: Credentials;
}

export class Login extends Component<any, LoginState> {

    public constructor(props: any) {
        super(props);
        this.state = {
            credentials: new Credentials()
        };
    }

    private setUsername = (e: ChangeEvent<HTMLInputElement>): void => {
        const username = e.target.value;
        this.setState({ credentials: { ...this.state.credentials, username } });
    };

    private setPassword = (e: ChangeEvent<HTMLInputElement>): void => {
        const password = e.target.value;
        this.setState({ credentials: { ...this.state.credentials, password } });
    };

    private login = (): void => {
        fetch("http://localhost:3001/api/login", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json"
            },
            body: JSON.stringify(this.state.credentials)
        })
            .then(response => response.json())
            .then(user => {
                if (user.error) {
                    alert("Incorrect username or password");
                    return;
                }
                // Save the user into the session storage before navigating to the vacations,
                // So in other pages we could know that this user has been logged-in:
                sessionStorage.setItem("user", JSON.stringify(user));
                store.dispatch({ type: ActionType.login, payload: user });
                store.dispatch({ type: ActionType.clearVacations });
                setTimeout(() => this.props.history.push("/vacations"),0);
            })
            .catch(err => alert(err));
    };

    public render(): JSX.Element {
        return (
            <div className="login">

                <h2>Login</h2>

                <form>

                    <input type="text" placeholder="Username..." onChange={this.setUsername} value={this.state.credentials.username || ""} />
                    <br /><br />

                    <input type="password" placeholder="Password..." onChange={this.setPassword} value={this.state.credentials.password || ""} />
                    <br /><br />

                    <button type="button" onClick={this.login}>Login</button>
                    <br/>
                    <NavLink to="/sign-up" exact><h3><i>New user? Sign up</i></h3></NavLink>

                </form>

            </div>
        );
    }
}