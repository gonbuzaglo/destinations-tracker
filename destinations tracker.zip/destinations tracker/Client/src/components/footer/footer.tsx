import React from 'react';
import './footer.css';

export const Footer: React.FC = (): JSX.Element => {
    return(
        <div className="footer">
            <p>&copy; All Rights Reserved 2019</p>
        </div>
    );
}